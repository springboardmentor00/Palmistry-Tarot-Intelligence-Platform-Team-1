import React, { useState } from 'react';

export default function SmartBroadcast() {
  const [targetRole, setTargetRole] = useState('ALL');
  const [targetGoal, setTargetGoal] = useState('ALL');
  const [inactiveOnly, setInactiveOnly] = useState(false);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [sentStatus, setSentStatus] = useState(null);

  const handleSend = (e) => {
    e.preventDefault();
    setSentStatus('Broadcasting payload to queue...');
    setTimeout(() => {
      setSentStatus('Broadcast queued successfully across targeted push/email push channels!');
      setTitle('');
      setMessage('');
    }, 1200);
  };

  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
      <h3 className="text-lg font-bold text-slate-900 mb-1">Smart Broadcast Dispatcher</h3>
      <p className="text-sm text-slate-500 mb-6">Dispatch targeted notifications based on user segments and inactivity windows.</p>

      <form onSubmit={handleSend} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Target User Role</label>
            <select
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-2 text-sm bg-slate-50 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="ALL">All Roles</option>
              <option value="USER">Standard User</option>
              <option value="TAROT_READER">Tarot Reader</option>
              <option value="SPIRITUAL_CONSULTANT">Spiritual Consultant</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Spiritual / Life Goal</label>
            <select
              value={targetGoal}
              onChange={(e) => setTargetGoal(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-2 text-sm bg-slate-50 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="ALL">All Life Goals</option>
              <option value="CAREER">Career & Wealth</option>
              <option value="RELATIONSHIP">Love & Relationships</option>
              <option value="PERSONAL_GROWTH">Personal Growth</option>
            </select>
          </div>

          <div className="flex items-center pt-5">
            <label className="flex items-center gap-2 cursor-pointer text-sm text-slate-700 font-medium">
              <input
                type="checkbox"
                checked={inactiveOnly}
                onChange={(e) => setInactiveOnly(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
              />
              Target 7+ Days Inactive Only
            </label>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Broadcast Title</label>
          <input
            type="text"
            required
            placeholder="e.g., Your Weekly Celestial Guidance is Ready"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full border border-slate-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Notification Body</label>
          <textarea
            required
            rows={3}
            placeholder="Enter prompt content or engagement message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="w-full border border-slate-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {sentStatus && (
          <div className="p-3 bg-indigo-50 text-indigo-700 text-xs rounded-lg font-medium">
            {sentStatus}
          </div>
        )}

        <button
          type="submit"
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm px-5 py-2.5 rounded-lg transition"
        >
          Dispatch Broadcast
        </button>
      </form>
    </div>
  );
}