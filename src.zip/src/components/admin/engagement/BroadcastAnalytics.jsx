import React from 'react';

const BROADCAST_HISTORY = [
  { id: 'bc-90', title: 'New Moon Reflection Cards', segment: 'All Users', sent: 8400, delivered: 8120, readRate: '64%', actionRate: '12%' },
  { id: 'bc-89', title: 'Specialist Slot Availability', segment: 'Inactive > 7 Days', sent: 1200, delivered: 1150, readRate: '41%', actionRate: '8%' },
  { id: 'bc-88', title: 'Palm Feature Insights Update', segment: 'Goal: Career', sent: 3100, delivered: 3050, readRate: '78%', actionRate: '24%' },
];

export default function BroadcastAnalytics() {
  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
      <h3 className="text-lg font-bold text-slate-900 mb-1">Broadcast Delivery & Read Analytics</h3>
      <p className="text-sm text-slate-500 mb-4">Historical push delivery KPIs and user interaction responses.</p>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
            <tr>
              <th className="p-3">Campaign</th>
              <th className="p-3">Target Segment</th>
              <th className="p-3">Delivered</th>
              <th className="p-3">Read Rate</th>
              <th className="p-3">Conversion</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {BROADCAST_HISTORY.map((bc) => (
              <tr key={bc.id} className="hover:bg-slate-50">
                <td className="p-3 font-medium text-slate-900">{bc.title}</td>
                <td className="p-3 text-slate-600">{bc.segment}</td>
                <td className="p-3 text-slate-600">{bc.delivered} / {bc.sent}</td>
                <td className="p-3 font-semibold text-indigo-600">{bc.readRate}</td>
                <td className="p-3 font-semibold text-emerald-600">{bc.actionRate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}