import React from 'react';

const FUNNEL_DATA = [
  { stage: 'Registered', count: 12450, color: 'bg-indigo-600' },
  { stage: 'Completed Profile', count: 8920, color: 'bg-blue-600' },
  { stage: 'First Reading', count: 5310, color: 'bg-purple-600' },
  { stage: 'Booked Consultation', count: 1420, color: 'bg-emerald-600' },
];

export default function ConversionFunnel() {
  const maxCount = FUNNEL_DATA[0].count;

  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
      <h3 className="text-lg font-bold text-slate-900 mb-1">User Onboarding Conversion Funnel</h3>
      <p className="text-sm text-slate-500 mb-6">Drop-off progression across core acquisition milestones.</p>

      <div className="space-y-4">
        {FUNNEL_DATA.map((item, index) => {
          const widthPct = Math.round((item.count / maxCount) * 100);
          const dropOff = index > 0 
            ? Math.round((1 - item.count / FUNNEL_DATA[index - 1].count) * 100) 
            : null;

          return (
            <div key={item.stage} className="relative">
              <div className="flex justify-between text-sm font-semibold mb-1">
                <span className="text-slate-800">{item.stage}</span>
                <span className="text-slate-600">{item.count.toLocaleString()} users ({widthPct}%)</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-8 overflow-hidden relative">
                <div
                  className={`h-full ${item.color} transition-all duration-500 flex items-center justify-end pr-3 font-bold text-xs text-white`}
                  style={{ width: `${widthPct}%` }}
                >
                  {widthPct > 15 && `${widthPct}%`}
                </div>
              </div>
              {dropOff !== null && (
                <div className="text-xs text-rose-500 font-medium mt-1 text-right">
                  ↓ {dropOff}% drop-off from previous step
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}