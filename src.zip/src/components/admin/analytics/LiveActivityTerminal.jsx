import React, { useState, useEffect } from 'react';

const MOCK_INITIAL_LOGS = [
  { id: 'log-101', timestamp: '2026-09-09T12:40:12Z', user: 'usr_882', event: 'PALM_UPLOAD', status: 'SUCCESS', metadata: { imageResolution: '1080x1920', lineDetectionConfidence: 0.94, hand: 'Right' } },
  { id: 'log-102', timestamp: '2026-09-09T12:41:05Z', user: 'usr_411', event: 'TAROT_SPREAD_GEN', status: 'SUCCESS', metadata: { spreadType: 'Celtic Cross', cardsDrawn: [1, 14, 22, 7], latencyMs: 230 } },
  { id: 'log-103', timestamp: '2026-09-09T12:42:19Z', user: 'usr_903', event: 'CONSULTATION_BOOK', status: 'PENDING', metadata: { specialistId: 'spec_12', slot: '2026-09-10T14:00:00Z', topic: 'Career' } },
  { id: 'log-104', timestamp: '2026-09-09T12:43:00Z', user: 'usr_105', event: 'AI_INSIGHT_ERR', status: 'FAILED', metadata: { provider: 'OpenAI', errorCode: 502, promptTokens: 1420 } },
];

export default function LiveActivityTerminal() {
  const [logs, setLogs] = useState(MOCK_INITIAL_LOGS);
  const [selectedLog, setSelectedLog] = useState(MOCK_INITIAL_LOGS[0]);
  const [isLive, setIsLive] = useState(true);

  // Auto-simulate incoming logs when live toggle is on
  useEffect(() => {
    if (!isLive) return;
    const interval = setInterval(() => {
      const newLog = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        user: `usr_${Math.floor(Math.random() * 900 + 100)}`,
        event: ['PALM_UPLOAD', 'TAROT_DRAW', 'PROFILE_UPDATE', 'REPORT_DOWNLOAD'][Math.floor(Math.random() * 4)],
        status: Math.random() > 0.15 ? 'SUCCESS' : 'FAILED',
        metadata: { sessionDuration: Math.floor(Math.random() * 300), region: 'US-East' },
      };
      setLogs((prev) => [newLog, ...prev.slice(0, 49)]);
    }, 4000);
    return () => clearInterval(interval);
  }, [isLive]);

  return (
    <div className="bg-slate-900 text-slate-100 p-6 rounded-xl border border-slate-800 font-mono shadow-2xl">
      <div className="flex justify-between items-center pb-4 mb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <span className={`h-3 w-3 rounded-full ${isLive ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
          <h2 className="font-bold text-lg text-white">Live Activity Terminal</h2>
          <span className="text-xs bg-slate-800 text-slate-400 px-2 py-1 rounded">Telemetry Engine v2</span>
        </div>
        <button
          onClick={() => setIsLive(!isLive)}
          className={`px-3 py-1 text-xs rounded font-semibold transition ${
            isLive ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-slate-800 text-slate-300'
          }`}
        >
          {isLive ? 'LIVE STREAMING' : 'PAUSED'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-96">
        {/* Stream List */}
        <div className="lg:col-span-7 overflow-y-auto pr-2 space-y-2">
          {logs.map((log) => (
            <div
              key={log.id}
              onClick={() => setSelectedLog(log)}
              className={`p-3 rounded-lg cursor-pointer text-xs transition border ${
                selectedLog?.id === log.id
                  ? 'bg-slate-800 border-indigo-500 text-white'
                  : 'bg-slate-950/60 border-slate-850 text-slate-400 hover:bg-slate-850'
              }`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="text-indigo-400 font-semibold">{log.event}</span>
                <span className="text-slate-500">{new Date(log.timestamp).toLocaleTimeString()}</span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>User: <strong className="text-slate-200">{log.user}</strong></span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                  log.status === 'SUCCESS' ? 'bg-emerald-900/50 text-emerald-400' : 'bg-rose-900/50 text-rose-400'
                }`}>
                  {log.status}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* JSON Viewer */}
        <div className="lg:col-span-5 bg-slate-950 p-4 rounded-lg border border-slate-800 overflow-y-auto">
          <div className="text-xs text-slate-400 mb-2 font-sans font-semibold">Raw Metadata Viewer</div>
          {selectedLog ? (
            <pre className="text-xs text-emerald-400 overflow-x-auto">
              {JSON.stringify(selectedLog, null, 2)}
            </pre>
          ) : (
            <p className="text-xs text-slate-600">Select a stream entry to view raw payload.</p>
          )}
        </div>
      </div>
    </div>
  );
}