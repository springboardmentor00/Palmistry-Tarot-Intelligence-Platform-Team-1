import React from 'react';

export default function DemographicUXCharts() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Age & Zodiac Distribution */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <h4 className="text-base font-bold text-slate-900 mb-4">Demographics: Age & Zodiac</h4>
        
        <div className="space-y-4">
          <div>
            <div className="text-xs text-slate-500 font-semibold mb-2">AGE GROUP SPLIT</div>
            <div className="flex gap-2 text-xs font-semibold">
              <div className="bg-indigo-100 text-indigo-700 py-2 rounded text-center" style={{ width: '45%' }}>18-24 (45%)</div>
              <div className="bg-indigo-200 text-indigo-800 py-2 rounded text-center" style={{ width: '35%' }}>25-34 (35%)</div>
              <div className="bg-indigo-300 text-indigo-900 py-2 rounded text-center" style={{ width: '20%' }}>35+ (20%)</div>
            </div>
          </div>

          <div className="pt-2">
            <div className="text-xs text-slate-500 font-semibold mb-2">TOP ZODIAC SIGNS</div>
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="border p-2 rounded bg-slate-50">♏ Scorpio (18%)</div>
              <div className="border p-2 rounded bg-slate-50">♓ Pisces (15%)</div>
              <div className="border p-2 rounded bg-slate-50">♊ Gemini (12%)</div>
            </div>
          </div>
        </div>
      </div>

      {/* Reading Depth & Life Goals */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <h4 className="text-base font-bold text-slate-900 mb-4">UX Preferences & Goals</h4>
        
        <div className="space-y-4">
          <div>
            <div className="text-xs text-slate-500 font-semibold mb-2">READING TYPE PREFERENCE</div>
            <div className="w-full bg-slate-100 h-6 rounded-full overflow-hidden flex text-xs text-white font-bold">
              <div className="bg-violet-600 flex items-center justify-center h-full" style={{ width: '68%' }}>Deep Insights (68%)</div>
              <div className="bg-amber-500 flex items-center justify-center h-full" style={{ width: '32%' }}>Standard (32%)</div>
            </div>
          </div>

          <div className="pt-2">
            <div className="text-xs text-slate-500 font-semibold mb-2">PRIMARY LIFE GOALS</div>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between"><span>Career Growth</span><span className="font-bold">42%</span></div>
              <div className="w-full bg-slate-100 h-2 rounded"><div className="bg-emerald-500 h-2 rounded" style={{ width: '42%' }} /></div>
              
              <div className="flex justify-between"><span>Relationships & Love</span><span className="font-bold">38%</span></div>
              <div className="w-full bg-slate-100 h-2 rounded"><div className="bg-rose-500 h-2 rounded" style={{ width: '38%' }} /></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}