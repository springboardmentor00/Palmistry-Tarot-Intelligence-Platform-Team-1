import React from 'react';
import LiveActivityTerminal from './analytics/LiveActivityTerminal';
import ConversionFunnel from './analytics/ConversionFunnel';
import DemographicUXCharts from './analytics/DemographicUXCharts';
import SmartBroadcast from './engagement/SmartBroadcast';
import BroadcastAnalytics from './engagement/BroadcastAnalytics';
import ReportArchive from './reports/ReportArchive';

export default function AnalyticsEngagementTab() {
  return (
    <div className="p-6 space-y-6 bg-slate-50 min-h-screen">
      <LiveActivityTerminal />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ConversionFunnel />
        <SmartBroadcast />
      </div>
      <DemographicUXCharts />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BroadcastAnalytics />
        <ReportArchive />
      </div>
    </div>
  );
}