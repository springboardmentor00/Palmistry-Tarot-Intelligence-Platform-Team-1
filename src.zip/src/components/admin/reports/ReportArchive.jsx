import React, { useState } from 'react';

const INITIAL_REPORTS = [
  { id: 'rep-301', user: 'Alice M.', type: 'Palmistry & Life Path', fileUrl: 'https://s3.amazonaws.com/reports/rep-301.pdf', date: '2026-09-08', status: 'READY' },
  { id: 'rep-302', user: 'David K.', type: 'Tarot Spread Synthesis', fileUrl: 'https://s3.amazonaws.com/reports/rep-302.pdf', date: '2026-09-09', status: 'READY' },
  { id: 'rep-303', user: 'Elena R.', type: 'Full Spiritual Guidance', fileUrl: null, date: '2026-09-09', status: 'PROCESSING' },
];

export default function ReportArchive() {
  const [reports, setReports] = useState(INITIAL_REPORTS);

  const triggerRegeneration = (id) => {
    setReports((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: 'REGENERATING...' } : r))
    );
    setTimeout(() => {
      setReports((prev) =>
        prev.map((r) => (r.id === id ? { ...r, status: 'READY' } : r))
      );
    }, 2000);
  };

  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
      <h3 className="text-lg font-bold text-slate-900 mb-1">Generated Report Archive</h3>
      <p className="text-sm text-slate-500 mb-4">Access generated PDF outputs or trigger asynchronous re-synthesis.</p>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase">
            <tr>
              <th className="p-3">Report ID</th>
              <th className="p-3">User</th>
              <th className="p-3">Report Type</th>
              <th className="p-3">Created Date</th>
              <th className="p-3">Status</th>
              <th className="p-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {reports.map((rep) => (
              <tr key={rep.id} className="hover:bg-slate-50">
                <td className="p-3 font-mono font-bold text-slate-700">{rep.id}</td>
                <td className="p-3 text-slate-900 font-medium">{rep.user}</td>
                <td className="p-3 text-slate-600">{rep.type}</td>
                <td className="p-3 text-slate-500">{rep.date}</td>
                <td className="p-3">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    rep.status === 'READY' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700 animate-pulse'
                  }`}>
                    {rep.status}
                  </span>
                </td>
                <td className="p-3 text-right space-x-2">
                  {rep.fileUrl && (
                    <a
                      href={rep.fileUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-indigo-600 hover:text-indigo-800 font-semibold underline"
                    >
                      Download
                    </a>
                  )}
                  <button
                    onClick={() => triggerRegeneration(rep.id)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded font-medium text-[11px]"
                  >
                    Regenerate
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}